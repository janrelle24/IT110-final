<!DOCTYPE html>
<html lang="en">
<head>
    <title>NotesApp</title> 
    <meta http-equiv="refresh" content="0 ; URL=login.php" />

</head>
<body>

</body>
</html>